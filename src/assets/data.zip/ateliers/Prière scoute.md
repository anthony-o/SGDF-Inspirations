# -->Thème

Prière scoute



# -->Sous-Thème

Prier



# -->Accueil

Lire la Prière scoute (comme un texte)



Seigneur Jésus, 

Apprenez-nous à être généreux,

A Vous servir comme Vous le méritez 

A donner sans compter, 

A combattre sans souci des blessures,

A travailler sans chercher le repos, 

A nous dépenser, sans attendre d'autre récompense,

que celle de savoir que nous faisons Votre Sainte Volonté.



# -->Parole.Titre

Prière scoute



# -->Parole.Texte



(à faire sous une forme théâtrale)



CHEF : Seigneur Jésus…   

JÉSUS : Oui ? Bonsoir !  



C : Hein ? Qui me parle ?  

J : Eh bien, c’est moi ! Jésus ! Tu viens de m’appeler !   



C : Je t’ai appelé ?   

J : Bien sûr ! Tu as dit « seigneur Jésus », et je suis Jésus ! Tu m’as appelé, je suis là ! Mais je ne veux pas te distraire, continue ta prière.   



C : Apprenez nous à être généreux…   

J : Comment veux-tu que je t’apprenne cela ?   



C : Mais heu… J’en sais rien ! Je dis ça parce que c’est la prière c’est tout ! C’est les paroles ! Et puis, c’est à moi d’apprendre tout seul, même si c’est dur !   

J : Non ! Je peux t’accompagner dans cet apprentissage, justement, parce que c’est dur pour l’Homme. Je suis à tes côtés. 



C : Oh… je n’avais pas vu les choses comme ça… A vous servir comme vous le méritez… 

J : Qu’est-ce que tu fais pour me servir ? 



C : Ce que je fais-moi ? Mais rien du tout ! Et les autres ? Ils font quoi ? Demande leur à eux ! 

J : Pourtant tu es chef, en tant que chef tu donnes de ton temps pour les plus jeunes ! Tu vas à la rencontre des différences. En fait, tu cherches à aimer et à aider ton prochain ! J’ai tort ? 



C : Non, mais ce sont mes jeunes, je les connais, ils me connaissent c’est pas pareil !! En plus j’ai l’impression qu’ils me donnent plus que je leur donne ! A donner sans compter… 

J : Pourquoi tu t’arrêtes ? 



C : Sans compter… ça non plus c’est pas facile ! On compte forcément un peu ! 

J : C’est dur oui, mais je pense vraiment que tu es sur la bonne voie ! 





C : A combattre sans soucis les blessures… 

J : Me fais-tu confiance ? 



C : Heu… je ne sais pas, ça dépend pour quoi j’imagine… 

J : Dans les tourments par exemple. Saurais-tu t’en remettre à moi ? 



C : Ah ! Tu veux dire que, quand on a des problèmes, on les combats, mais on doit te faire confiance, pour nous aider, ne pas se décourager, parce qu’on sait que tu es avec nous ? Bah écoute… j’ai envie d’essayer ! 

J : Oui c’est ça ! Je suis heureux que tu fasses ce pas ! 





C : À travailler sans chercher le repos. Mais, Seigneur, on a besoin de dormir quand même, non ? Tu nous as fait comme ça. Et puis une petite sieste ça fait toujours plaisir ! 

J : Oui bien sûr ! Vois plutôt cette phrase comme une invitation à résister à la paresse. Par exemple, quand tu prépares une animation, tu cherches à faire quelque chose de motivant, original, éducatif. Tu ne choisis pas de de laisser tes jeunes avec un ballon et c’est tout ! C’est déjà excellent ! 



C : C’est pas faux… A nous dépenser sans attendre d’autres récompenses que celle de savoir que nous faisons votre sainte volonté. 

J : As-tu une idée de ce qu’est ma volonté ? 



C : Heu… 

J : Un indice : qu’ai-je dit aux apôtres ? 



C : Aimez-vous les uns les autres, comme je vous ai aimés. C’est ça ? 

J : Oui ! Vois-tu le lien avec ton engagement en tant que chef scout ? 



C : Bah c’est vrai que, entant que chef, je donne de mon temps et de mon énergie, et ce qui me fait le plus plaisir, c’est de voir mes jeunes avec un sourire jusqu’aux oreilles… En fait je veux savoir que j’ai bien pris soin d’eux. Que je leur ai donné un amour vrai !



# -->Parole.Reference

-



# -->Geste.Titre

Temps pour soi



# -->Geste.Texte

Chacun prend un temps pour soi, pour réciter en lui même (ou lire en silence) la prière scoute



# -->Envoi







Seigneur, aide nous à profiter de cette journée 

pour apprendre… apprendre à être généreux

pour servir… vous servir comme vous le méritez

à donner… donner sans compter

à lutter… sans soucis de nos blessures

à travailler… sans chercher le repos

à nous donner à fond… sans attendre d’autre récompense que celle de savoir que nous faisons votre sainte volonté





Chanter la prière scoute ensemble



Seigneur Jésus, 

Apprenez-nous à être généreux,

A Vous servir comme Vous le méritez 

A donner sans compter, 

A combattre sans souci des blessures,

A travailler sans chercher le repos, 

A nous dépenser, sans attendre d'autre récompense,

que celle de savoir que nous faisons Votre Sainte Volonté.





# -->Tranche(s) d'âges

14-17,17-18



