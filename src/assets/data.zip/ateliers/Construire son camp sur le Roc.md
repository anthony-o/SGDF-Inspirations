# -->Thème

Démarrer un camp



# -->Sous-Thème

Plusieurs membres, un seul corps



# -->Accueil

Chant: Contre vents et marée

https://www.youtube.com/watch?v=ZYYGY5Pg02I



# -->Parole.Titre

Construire sa maison sur le roc



# -->Parole.Texte

Comme les disciples s’étaient rassemblés autour de Jésus, sur la montagne, il leur disait: «Il ne suffit pas de me dire: “Seigneur, Seigneur!” pour entrer dans le Royaume des cieux; mais il faut faire la volonté de mon Père qui est aux cieux.

«Tout homme qui écoute ce que je vous dis là et le met en pratique est comparable à un homme prévoyant qui a bâti sa maison sur le roc. La pluie est tombée, les torrents ont dévalé, la tempête a soufflé et s’est abattue sur cette maison; la maison ne s’est pas écroulée, car elle était fondée sur le roc.

«Et tout homme qui écoute ce que je vous dis là sans le mettre en pratique est comparable à un homme insensé qui a bâti sa maison sur le sable. La pluie est tombée, les torrents ont dévalé, la tempête a soufflé, elle a secoué cette maison; la maison s’est écroulée, et son écroulement a été complet.

.

# -->Parole.Reference

Matthieu 7, 24-27



# -->Geste.Titre

Choisir une pierre



# -->Geste.Texte



Notre camp est comme ces maisons construites sur le sable ou sur le roc. Pour qu’il tienne pendant une ou deux semaines, il faut que les nœuds soient bien faits, que le bois ne soit pas pourri, etc. Mais cela ne suffit pas , le roc de nos vies, sur lequel nous sommes invités à tout construire, c’est Dieu. Grâce à lui, ce que nous construisons est durable et vrai. Sur quelles bases pouvons-nous construire notre camp pour qu’il soit aussi un moment de joie et de vérité ? 



Geste : chacun prend une pierre qui représentera ce qu’il pense nécessaire pour un bon déroulement du camp (bonne humeur, bienveillance, etc). On prend un petit temps de silence pour demander à Dieu de nous aider à vivre ce que nous lui demandons puis chacun vient empiler sa pierre sous la croix (ou selon le lieu) pour construire le camp sur des bases saines et solides.



# -->Envoi



###chant d’envoi



Chant: le fou sur le sable a bâti sa maison



https://www.youtube.com/watch?v=w3Et9DATFy8





-->Tranche(s) d'âges

8-11,11-14, 14-17

