# <a id="_2ejsgjjqnjr7"></a>\-\->Thème

Vivre

# <a id="_l7y7qexcjx90"></a>\-\->Sous\-Thème

La vie est une chaaance

# <a id="_ierg6yi4c4t3"></a>\-\->Accueil

L’accueil est à travailler\.

# <a id="_nhvnm3uzwjrc"></a>\-\->Parole\.Titre

La vie est une chance

# <a id="_v34pes1usanj"></a>\-\->Parole\.Texte

La vie

La vie est une chance, saisis\-la\.

La vie est beauté, admire\-la\.

La vie est béatitude, savoure\-la\.

La vie est un rêve, fais\-en une réalité\.

La vie est un défi, fais\-lui face\.

La vie est un devoir, accomplis\-le\.

La vie est un jeu, joue\-le\.

La vie est précieuse, prends\-en soin\.

La vie est une richesse, conserve\-la\.

La vie est amour, jouis\-en\.

La vie est un mystère, perce\-le\.

La vie est promesse, remplis\-la\.

La vie est tristesse, surmonte\-la\.

La vie est un hymne, chante\-le\.

La vie est un combat, accepte\-le\.

La vie est une tragédie, prends\-la à bras\-le\-corps\.

La vie est une aventure, ose\-la\.

La vie est bonheur, mérite\-le\.

La vie est la vie, défends\-la\.

*Mère Teresa*

# <a id="_arxa68u5gmec"></a>\-\->Parole\.Reference

La vie, Mère Teresa

# <a id="_du29hiwww0m2"></a>\-\->Geste\.Titre

Prendre une pincée de sel

# <a id="_apwu9nd0o0nz"></a>\-\->Geste\.Texte

La vie est une chance, c'est à nous d'en saisir le gout\.

Ce n'est pas toujours simple, souvent on préfère les choses sans gout, sans odeur, sans risque\.\.\.\.

On vous donne à chacun une pincé de sel \(gros sel si possible\), on vous propose de la mettre dans votre bouche en même temps\.

ça va piquer un peu, acceptez le, réjouissez vous et que ce gout vous accompagne dans la journée

# <a id="_3avozeuj0b81"></a>\-\->Envoi

Vous le sel de la terre

[https://www\.youtube\.com/watch?v=G2QXOfLk2Gw](https://www.youtube.com/watch?v=G2QXOfLk2Gw)

# <a id="_l2fnnksgu2pt"></a>\-\->Tranche\(s\) d'âges

14\-17

