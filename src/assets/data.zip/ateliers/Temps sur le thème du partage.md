# -->Thème

Démarrer un camp



# -->Sous-Thème

Partage



# -->Accueil

Chacun prend 2mn pour regarder le paysage autour de lui et choisit ce qu’il trouve le plus beau.

Chacun annonce ce qu’il a retenu



# -->Parole.Titre

Dieu éclate tellement dans toute sa création



# -->Parole.Texte

“D’abord, promène toi lentement et regarde. Dieu éclate tellement dans toute sa création, que pour ne pas le voir et le louer, il faut être bien aveugle. 



Il resplendit dans les fleurs et les oiseaux, les astres et les eaux, les arbres et les montagnes. Il se déploie dans l’infiniment grand et l’infiniment petit, surabonde en formes, en couleurs et en rythmes dans les champs, les fortes, les déserts. 



Car Dieu se manifeste: “Depuis la création du monde, les hommes, avec leur intelligence, peuvent voir, à travers les œuvres de Dieu, ce qui est invisible: sa puissance éternelle et sa divinité.” 



Ensuite, marche ou assieds-toi. Tu es seul avec la nature qui t’entoure: la végétation, les animaux, le ciel… Respire les différents parfums. 



Ecoute et laisse monter en toi la prière

.

# -->Parole.Reference

-



# -->Geste.Titre

Admirer, remercier, prier. 



# -->Geste.Texte



Chacun prend un temps pour s’éloigner un peur, regarder la création qui l’entoure, admirer et prier: remercier..  





# -->Envoi



Psaume de la création



https://www.youtube.com/watch?v=Lje_aWoQnnQ





Refrain : Je veux crier mon Dieu ! Tu es grand, Tu es beau, Dieu vivant, Dieu très-haut, Tu es le Dieu d'amour ! Mon Dieu, Tu es grand, Tu es beau, Dieu vivant, Dieu très-haut Dieu présent en toute création.Par les cieux devant Toi, Splendeur et majesté Par l'infiniment grand, l'infiniment petit, Et par le firmament, Ton manteau étoilé, Et par frère soleil... RefrainPar tous les océans et toutes les mers, Par tous les continents et par l'eau des rivières, Par le feu qui Te dit comme un buisson ardent Et par l'aile du vent... RefrainPar toutes les montagnes et toutes les vallées, Par l'ombre des forêts et par les fleurs des champs, Par les bourgeons des arbres et l'herbe des prairies, Par le blé en épis... RefrainPar tous les animaux de la terre et de l'eau, Par le chant des oiseaux, par le chant de la vie, Par l'homme que Tu fis juste moins grand que Toi Et par tous ses enfants... RefrainPar cette main tendue qui invite à la danse, Par ce baiser jailli d'un élan d'espérance, Par ce regard d'amour qui relève et réchauffe, Par le pain et le vin... Refrain

-->Tranche(s) d'âges

8-11,11-14, 14-17

