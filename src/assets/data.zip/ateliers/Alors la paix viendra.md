# -->Thème

Prise de recul



# -->Sous-Thème

Bienheureux ceux qui procurent la paix



# -->Accueil

Chant: Da pacem Domine



# -->Parole.Titre

Alors la paix viendra



# -->Parole.Texte

# Alors, la paix viendra

Si tu crois qu’un sourire est plus fort qu’une arme,  

Si tu crois à la puissance d’une main offerte,  

Si tu crois que ce qui rassemble les hommes est plus important que ce qui les divise,  

Si tu crois qu’être différent est une richesse et non pas un danger,  

Si tu sais regarder l’autre avec un brin d’amour.  

Si tu sais préférer l’espérance au soupçon...



### Alors, la paix viendra

Si tu estimes que c’est à toi de faire le premier pas plutôt qu’à l’autre,  

Si le regard d’un enfant parvient encore à désarmer ton cœur,  

Si tu peux te réjouir de la joie de ton voisin.  

Si l’injustice qui frappe les autres te révolte autant que celle que tu subis,  

Si pour toi l’étranger est un frère qui t’es proposé,  

Si tu sais donner gratuitement un peu de ton temps par amour.  

Si tu sais accepter qu’un autre te rende service,  

Si tu partages ton pain et que tu saches y joindre un morceau de ton cœur  

Si tu crois qu’un pardon va plus loin qu’une vengeance...  



### Alors, la paix viendra

Si tu sais chanter le bonheur des autres et danser leur allégresse,  

Si tu peux écouter le malheureux que te fait perdre ton temps et lui garder ton sourire,  

Si tu sais accepter la critique et en faire ton profit sans la renvoyer et te défendre.  

Si tu sais accueillir et adopter un avis différent du tien...  



### Alors, la paix viendra

Si tu refuses de battre ta coulpe sur la poitrine des autres,  

Si pour toi l’autre est d’abord un frère,  

Si la colère est pour toi une faiblesse, non une preuve de force,  

Si tu préfères être lésé plutôt que de faire tort à quelqu’un,  

Si tu refuses qu’après toi ce soit le déluge,  

Si tu te ranges du côté du pauvre et de l’opprimé sans te prendre pour un héros,   

Si tu crois que l’amour est la seule force de persuasion,  

Si tu crois que la paix est possible



### ALORS LA PAIX VIENDRA



# Matthieu 5,1-12

Or, voyant les foules, il monta sur la montagne ; et lorsqu’il se fut assis, ses disciples s’approchèrent de lui ;  

et ayant ouvert la bouche, il les enseignait, disant :  

Bienheureux les pauvres en esprit, car c’est à eux qu’est le royaume des cieux ;  

bienheureux ceux qui mènent deuil, car c’est eux qui seront consolés ;  

bienheureux les débonnaires, car c’est eux qui hériteront de la terre ;  

bienheureux ceux qui ont faim et soif de la justice, car c’est eux qui seront rassasiés ;  

bienheureux les miséricordieux, car c’est à eux que miséricorde sera faite ;  

bienheureux ceux qui sont purs de cœur, car c’est eux qui verront Dieu ;  

bienheureux ceux qui procurent la paix, car c’est eux qui seront appelés fils de Dieu ;  

bienheureux ceux qui sont persécutés à cause de la justice, car c’est à eux qu’est le royaume des cieux.  

Vous êtes bienheureux quand on vous injuriera, et qu’on vous persécutera, et qu’on dira, en mentant, toute espèce de mal contre vous, à cause de moi.  

Réjouissez-vous et tressaillez de joie, car votre récompense est grande dans les cieux ; car on a persécuté ainsi les prophètes qui ont été avant vous



# -->Parole.Reference

Matthieu 5,1-12



# -->Geste.Titre

Identifier les richesses de ma vie



# -->Geste.Texte

Matériel:



Un colombe dessinée sur un papier (ou en alors en origami,  https://www.youtube.com/watch?v=t7z1tvq4bvg  )



Il est facile de dire: ""Je suis d'accord pour faire la paix"", et de se serrer la main le dimanche à l'église. Pour autant sommes nous près à faire la paix ?



Suis-je près à faire la paix ? Suis-je près à abandonner mes peurs, mes colère, mes haines.



Chacun d'idendifier une de ses peurs, une de ses colères, une de ses haines, une des ses craintes. Une rien qu'une.



Et de faire la paix, avec celle ci. 



A ce moment chacun peut venir prendre une colombe au centre du groupe, et la garde avec lui durant la journée pour qu'elle l'aide à conserver cette paix.



# -->Envoi

Chant: Canon de la paix  https://www.youtube.com/watch?v=r0eZmpWgFok



Pam pam pam pam pam  

Pam pam pam pam pam  

•  

La la la la la la  

La la la la la la  

•  

Ecoutez, le temps viendra,  

Les hommes un jour saurons  la Vérité,  

Le lion s'étendra près de l'agneau.  

Et nous fondrons les piques pour des faux  

Et des socs pour des herses.  

La paix sera notre combat,  

Faîtes que ce temps vienne



# -->Tranche(s) d'âges

11-14,14-17,17-18,Farfadets,Marins,Responsables,Vent du large



