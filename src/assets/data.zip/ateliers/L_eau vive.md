# -->Thème

Le Don de Dieu



# -->Sous-Thème

L’eau vive



# -->Accueil







1 - Comme l'argile se laisse faire 

entre les mains agiles du potier, 

Ainsi mon âme se laisse faire, 

ainsi mon cœur te cherche, toi mon Dieu. 



Je viens vers toi, Jésus, (bis) 

Je viens vers toi, Jésus. (bis) 



2 - Comme une terre qui est aride, 

ainsi mon cœur désire ton eau vive. 

Tu es la source qui désaltère : 

qui croit en toi n'aura plus jamais soif.

 

3 - Comme un veilleur attend l'aurore 

ainsi mon âme espère en ta Parole. 

Car ta Parole est une lampe, 

une lumière allumée sur mes pas.



https://www.youtube.com/watch?v=SxxXK05hjXA



# -->Parole.Titre

La Samaritaine, 



# -->Parole.Texte



Il arrive donc à une ville de Samarie, appelée Sykar, près du terrain que Jacob avait donné à son fils Joseph.

Là se trouvait le puits de Jacob. Jésus, fatigué par la route, s’était donc assis près de la source. C’était la sixième heure, environ midi.

Arrive une femme de Samarie, qui venait puiser de l’eau. Jésus lui dit : « Donne-moi à boire. »

– En effet, ses disciples étaient partis à la ville pour acheter des provisions.

La Samaritaine lui dit : « Comment ! Toi, un Juif, tu me demandes à boire, à moi, une Samaritaine ? » – En effet, les Juifs ne fréquentent pas les Samaritains.

Jésus lui répondit : « Si tu savais le don de Dieu et qui est celui qui te dit : “Donne-moi à boire”, c’est toi qui lui aurais demandé, et il t’aurait donné de l’eau vive. »

Elle lui dit : « Seigneur, tu n’as rien pour puiser, et le puits est profond. D’où as-tu donc cette eau vive ?

Serais-tu plus grand que notre père Jacob qui nous a donné ce puits, et qui en a bu lui-même, avec ses fils et ses bêtes ? »

Jésus lui répondit : « Quiconque boit de cette eau aura de nouveau soif ;

mais celui qui boira de l’eau que moi je lui donnerai n’aura plus jamais soif ; et l’eau que je lui donnerai deviendra en lui une source d’eau jaillissant pour la vie éternelle. »

La femme lui dit : « Seigneur, donne-moi de cette eau, que je n’aie plus soif, et que je n’aie plus à venir ici pour puiser. »



Comme la Samaritaine, Dieu vient vers nous car dans son amour, il veut avoir besoin de nous. Mais ce qu’il nous offre en échange va bien au-delà de toute espérance. 

.

# -->Parole.Reference

Jean 4, 5-15



# -->Geste.Titre

Admirer, remercier, prier. 



# -->Geste.Texte



Chacun écrit sur un papier quelque chose que le camp lui a apporté/lui apporte et qu’il n’attendait pas. Quelque chose qui va au-delà de ce qu’il espérait de ce camp. 

On l’écrit sur un papier au feutre (important !) pour remercier Dieu et chacun met ce papier dans une petite gamelle avec de l’eau. L’encre du feutre se dissout dans l’eau. Ensuite on verse cette eau au pied de la croix (ou au centre du cercle selon le lieu) et ces louanges vont monter vers Dieu en s’évaporant.





# -->Envoi



Chant: Je veux chanter ton amour Seigneur 



https://www.youtube.com/watch?v=9-GZ26qT7iA



Je veux chanter ton amour, Seigneur, Chaque instant de ma vie,   Danser pour toi en chantant ma joie  Et glorifier ton nom.   1-Ton amour pour nous est plus fort que tout   Et tu veux nous donner la vie, Nous embraser par ton Esprit.  Gloire à toi ! 2- Oui Tu es mon Dieu,Tu es mon Seigneur.Toi seul est mon libérateur,Le rocher sur qui je m'appuie.Gloire à toi !3- Car Tu es fidèle,Tu es toujours là,Tout près de tous ceux qui te cherchent.Tu réponds à ceux qui t'appellent.Gloire à toi !4- Voici que Tu viensAu milieu de nous,demeurer au coeur de nos viesPour nous mener droit vers le père.Gloire à toi !5- Avec toi, Seigneur,je n'ai peur de rien.Tu es là sur tous mes chemins.Tu m'apprends à vivre l'amour.Gloire à toi 

-->Tranche(s) d'âges

8-11,11-14, 14-17

