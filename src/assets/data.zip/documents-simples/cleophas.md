https://www.sgdf.fr/vos-ressources/doc-en-stock/category/9-animation-pastorale?download=2044:cleophas-part-en-camp-2017

