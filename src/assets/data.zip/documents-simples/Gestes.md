

Passer une porte : 

Franchir une étape ; Entrer dans un temps de vie.  



Apporter, déposer une pierre. 

Apporter des fautes ; Apporter ses souffrances.  



Se serrer la main ; 

Se donner les mains. Faire la paix ; Dire non à la violence.  



Laver les mains de l’autre.

Se mettre au service ; Humilité.  

Se laver les mains.

Se purifier.Développer la confiance  



Confier un objet auquel je tiens: 

Se mettre en route.  

Prendre son sac sur le dos ; 

Prendre son bâton.  

Ouvrir les mains.

Se préparer à accueillir.  

Prendre un temps de silence ; 

Fermer les yeux.  



Former un bouquet de fleurs.

S’intéresser a ce qui se passe en nous ;  

Semer une graine.

Apporter chacun son utilité ; La beauté gratuite.  

Marcher.

Penser à l’avenir.  



Se transmettre le feu avec des bougies. 

Propager ; Transmettre.  

Brûler de mauvaises herbes. 

Renoncer en nous à ce qui empêche les bons cotés de s’exprimer.  



Prendre une pincé de sel et la goûter. 

Donner du « goût » à nos vies ;  

Monter une tente. 

Se rappeler que nous sommes scouts ; Faire une étape dans notre vie ; Bâtir un abri.  



Signe de croix. 

Ouvrir une porte vers Dieu.  





