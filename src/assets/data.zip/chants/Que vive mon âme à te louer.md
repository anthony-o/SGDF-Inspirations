# -->Titre

Que vive mon âme à te louer



# -->Texte

## Que vive mon âme à te louer





Refrain: Que vive mon âme à Te louer!

Tu as posé une lampe, une lumière sur ma route,

Ta parole, Seigneur, Ta parole, Seigneur.



1- Heureux ceux qui marchent dans tes voies, Seigneur ! De tout mon cœur, je veux garder ta parole, Ne me délaisse pas, Dieu de ma joie.2- Heureux ceux qui veulent faire ta volonté !Je cours sans peur sur la voie de tes préceptesEt mes lèvres publient ta vérité.3. Heureux ceux qui suivent tes commandements !Oui plus que l'or, que l'or fin j'aime ta loi, Plus douce que le miel est ta promesse.4. Heureux ceux qui méditent sur la sagesse !Vivifie-moi, apprends-moi tes volontés ; Dès l'aube, de ta joie tu m'as comblé.





https://www.youtube.com/watch?v=VFQDBnZXifc





