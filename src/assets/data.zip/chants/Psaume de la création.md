# -->Titre

Psaume de la Création



# -->Texte



https://www.youtube.com/watch?v=Lje_aWoQnnQ





Refrain : Je veux crier mon Dieu ! Tu es grand, Tu es beau, Dieu vivant, Dieu très-haut, Tu es le Dieu d'amour ! Mon Dieu, Tu es grand, Tu es beau, Dieu vivant, Dieu très-haut Dieu présent en toute création.Par les cieux devant Toi, Splendeur et majesté Par l'infiniment grand, l'infiniment petit, Et par le firmament, Ton manteau étoilé, Et par frère soleil... RefrainPar tous les océans et toutes les mers, Par tous les continents et par l'eau des rivières, Par le feu qui Te dit comme un buisson ardent Et par l'aile du vent... RefrainPar toutes les montagnes et toutes les vallées, Par l'ombre des forêts et par les fleurs des champs, Par les bourgeons des arbres et l'herbe des prairies, Par le blé en épis... RefrainPar tous les animaux de la terre et de l'eau, Par le chant des oiseaux, par le chant de la vie, Par l'homme que Tu fis juste moins grand que Toi Et par tous ses enfants... RefrainPar cette main tendue qui invite à la danse, Par ce baiser jailli d'un élan d'espérance, Par ce regard d'amour qui relève et réchauffe, Par le pain et le vin... Refrain





