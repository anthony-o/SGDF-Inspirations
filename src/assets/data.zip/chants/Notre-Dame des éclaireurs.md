

# -->Titre

Notre-Dame des éclaireurs



# -->Texte

## Notre-Dame des éclaireurs



Notre-Dame des éclaireursMusique : cantique ancienParoles : Père Jacques SevinÉcrit en : 19201er coupletLe soir étend sur la terreSon grand manteau de veloursEt le camp calme et solitaireSe recueille en ton amour.•RefrainÔ Vierge de lumière,Etoile de nos coeurs,Entend notre prière,Notre-Dame des éclaireurs.•2e coupletO douce Dame aux étoilesJette un regard sur ce campOù tes fils, sous leurs frêles toiles,Vont dormir en t'invoquant.•Refrain•3e coupletO toi plus blanche que neigeRavie au Mont virginalTa beauté, Vierge, nous protègeContre la laideur du mal.•Refrain•4e coupletQue tes bontés maternellesVeillent sur ceux qui sont tiens ;Place ici comme sentinellesLes bons anges nos gardiens.•Refrain•5e coupletComme les tentes légèresQue l'on roule pour partir,Garde-nous, âmes passagères,Toujours prêtes à mourir.•Refrain•6e coupletFais-nous quitter l'existenceJoyeux et pleins d'abandon,Comme un scout, après les vacances,S'en retourne à la maison.•Refrain





https://www.youtube.com/watch?v=E-v-4j1-jME

