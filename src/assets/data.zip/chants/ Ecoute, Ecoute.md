# -->Titre

 Ecoute, Ecoute



# -->Texte

## ECOUTE, ECOUTE



1. Ils ont marché au pas des siècles vers un pays de joie.

Ils ont marché vers la lumière pour habiter la joie.



Écoute, écoute, surtout ne fais pas de bruit,

On marche sur la route, on marche dans la nuit.

Écoute, écoute, les pas du Seigneur vers toi,

Il marche sur ta route, il marche près de toi.



2. Ils ont laissé leurs cris de guerre pour des chansons de paix.

Ils ont laissé leur bout de terre pour habiter la paix.



3. Ils sont venus les mains ouvertes pour accueillir l'amour.

Ils sont venus chercher des frères pour habiter l'amour.





https://www.youtube.com/watch?v=0RLWTeQqG2c



