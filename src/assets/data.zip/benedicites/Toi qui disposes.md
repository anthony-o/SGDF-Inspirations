

# -->Titre

Toi qui dispose



# -->Texte

sur l’air de “Oh when the Saints”



Toi qui dispose

De toute choses

Et nous les donnes chaque jour

Reçois, ô Père, notre prière

De reconnaissance et d’amour





https://www.youtube.com/watch?v=dBDksMqN11M&index=26&list=PLVB2dphYKAKsDlaYLzfMSeNHpLiy1k_PK

