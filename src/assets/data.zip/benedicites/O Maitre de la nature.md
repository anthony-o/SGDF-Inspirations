

# -->Titre

Toi qui dispose



# -->Texte

sur l’air de l’hymne à la joie



O Maître de la nature

Toi qui fait germer les blés

Bénis notre nourriture 

donne à tous de quoi manger



nous qui sommes tous des frères 

apprends nous à partager

pour que sur la terre entière 

tous les hommes puissent demeurer







https://www.youtube.com/watch?v=yYLGvRqiToQ&list=PLVB2dphYKAKsDlaYLzfMSeNHpLiy1k_PK&index=28

