

# -->Titre

Pour les champs de blé



# -->Texte

Pour les champs de blé, Merci !

L’herbe ensoleillée, Merci !

Les ruisselets, Merci !

Que Grâce te soit rendue





Pour toute beauté, Merci !

Pour toute bonté, Merci !

Pour toute amitié, Merci !

Que Grâce te soit rendu



https://www.youtube.com/watch?v=kNZYK_cXcKY&list=PLVB2dphYKAKsDlaYLzfMSeNHpLiy1k_PK&index=10

