

# -->Titre

Bénis o notre père



# -->Texte

sur l’air de “O”A la claire fontaine”



Bénis, ô notre père 

le repas de ce jour

Bénis les cuisiniers 

qui nous chauffèrent le four

Bon appétit petit frère

Restons unis pour toujours





https://www.youtube.com/watch?v=vws9YSqpy8E&index=29&list=PLVB2dphYKAKsDlaYLzfMSeNHpLiy1k_PK

