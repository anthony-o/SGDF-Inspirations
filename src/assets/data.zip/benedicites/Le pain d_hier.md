

# -->Titre

Le pain d’hier est fini



# -->Texte

Le pain d’hier est fini

Le pain de demain n’est pas cuit

Merci Seigneur pour le pain d’aujourd’hui 

Et à tous bon appétit



https://www.youtube.com/watch?v=ghHbyCPoxCQ&index=5&list=PLVB2dphYKAKsDlaYLzfMSeNHpLiy1k_PK

