

# -->Titre

Tu nous donnes (canon)



# -->Texte



Il s’agit d’un texte à chanter en canon sur l’air de frère Jacques

Les 2 voies ont les mêmes paroles et les décalent d’une phrase.



1- Tu nous donnes (x2)



1 - Ce repas (x2)

2 > Tu nous donnes (x2)



1 -Nous te rendons grâce (x2)

2 > Ce repas (x2)



1 - Dieu d’amour (x2)

2 > Nous te rendons grâce (x2)



2 > Ce repas (x2)



https://www.youtube.com/watch?v=saU76gZVGK0&index=15&list=PLVB2dphYKAKsDlaYLzfMSeNHpLiy1k_PK

