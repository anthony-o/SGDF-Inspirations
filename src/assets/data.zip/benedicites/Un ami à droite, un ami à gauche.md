

# -->Titre

Un ami à droite, un ami à gauche



# -->Texte



Un ami à droite,

Un ami à gauche 

A tous bon appétit



Merci Seigneur pour ce repas

Merci Seigneur pour ces bons plats

Merci Seigneur pour toute joie

A tous bon appétit



https://www.youtube.com/watch?v=BGJMGDCxPyY&index=3&list=PLVB2dphYKAKsDlaYLzfMSeNHpLiy1k_PK

