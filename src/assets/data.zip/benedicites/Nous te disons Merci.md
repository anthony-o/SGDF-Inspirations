

# -->Titre

Nous te disons merci



# -->Texte

Nous te disons Merci Seigneur,

Nous te disons Merci

(x2)



Pour le pain partagé, 

Les amis rencontrés,

Nosu te disons merci



https://www.youtube.com/watch?v=GLMe8DIP0b4&list=PLVB2dphYKAKsDlaYLzfMSeNHpLiy1k_PK&index=30

