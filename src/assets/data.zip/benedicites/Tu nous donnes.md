

# -->Titre

Seigneur pour tous tes dons,



# -->Texte

Seigneur pour tous tes dons,

Nous te disons notre reconnaissance

Partageons l’amitié

Fais en nous régner ta vive présence

(x2)



https://www.youtube.com/watch?v=saU76gZVGK0&index=15&list=PLVB2dphYKAKsDlaYLzfMSeNHpLiy1k_PK

