

# -->Titre

Compagnons partageons ce pain



# -->Texte

Compagnons partageons ce pain

Mangeons tous car nous avons faim

Dieu nous comble de ses dons

Compagnons, compagnons



https://www.youtube.com/watch?v=Mn4ncZ5qcS8&index=8&list=PLVB2dphYKAKsDlaYLzfMSeNHpLiy1k_PK

