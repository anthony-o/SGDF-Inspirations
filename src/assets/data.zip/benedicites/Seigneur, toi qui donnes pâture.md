

# -->Titre

Seigneur, toi qui donne pature



# -->Texte

Seigneur, toi qui donne pature

aux tout petits petits oiseaux

Viens bénir notre nourriture 

et purifier notre eaux

Amen, Amen



https://www.youtube.com/watch?v=Egh1W3hl-eE&list=PLVB2dphYKAKsDlaYLzfMSeNHpLiy1k_PK&index=16

