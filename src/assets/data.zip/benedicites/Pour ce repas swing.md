

# -->Titre

Pour ce repas swing (canon)



# -->Texte



Pour ce repas

Pour ce repas, pour toute joie



Pour ce repas

Pour ce repas, pour toute joie



Pour ce repas

Pour ce repas, pour toute joie



Nous te louons, Seigneur !

Nous te louons, Seigneur !



https://www.youtube.com/watch?v=9ZU9M0ie7gk&index=21&list=PLVB2dphYKAKsDlaYLzfMSeNHpLiy1k_PK

