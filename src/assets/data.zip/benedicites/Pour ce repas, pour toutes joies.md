

# -->Titre

Pour ce repas, pour toute joie



# -->Texte

Pour ce repas, pour toute joie,

Nous te louons Seigneur

Pour tes bienfaits

O Dieu de Paix

Nous te louons Seigneur



https://www.youtube.com/watch?v=saU76gZVGK0&index=15&list=PLVB2dphYKAKsDlaYLzfMSeNHpLiy1k_PK

