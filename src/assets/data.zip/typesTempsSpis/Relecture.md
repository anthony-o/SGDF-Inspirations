\# \-\->Titre

###### <a id="_3o9t84kcxr04"></a>Relecture

\# \-\->Texte

###### <a id="_laabwn61k953"></a>L'Évaluation mesure et quantifie le vécu\.

###### <a id="_xeueszh6bw2a"></a>alors que:

###### <a id="_mdqcixykjx9i"></a>La Relecture recherche le sens et les motivations de ce qui a été vécu en référence à Dieu, à son peuple et à l’Evangile\.

__\# 1ère technique de relecture : LA MAIN__

__\#\#1\. Pouce, je m’arrête :__

S’arrêter à l’image de Dieu après la Création : Dieu vit que « cela était bon »\.

« Je laisse donc revenir à la mémoire le « film » vécu ; avant de vivre une autre page de ma vie\. Je cite dans ce « film » les points importants qui m’ont touché, qui m’ont marqué\. »

 

__\#\#2\. L’index, montre le chemin :__

Le doigt de Jean Baptiste désignant Jésus « Voici l’agneau de Dieu »\.

« L’index me montre les moments vécus : heureux ou non\. Pourquoi l’ont\-ils été ? En suis\-je responsable ? Quel a été mon rôle, ma conscience de la situation ? »

 

__\#\#3\. Le majeur à l’image de la grandeur du Christ :__

Le Christ est le plus grand : je peux compter sur lui\.

« Parmi tous les obstacles qui m’éloignent de Dieu, des hommes, de la vie, je repère un combat à mener\. Ce sera mon point d’attention pour les jours à venir\. »

 

__\#\#4\. L’annulaire, signe de l’alliance avec Dieu :__

Quand est\-il de mon alliance avec Dieu ?

« Je suis donc invité à remercier, à dire s’il te plait, à demander pardon, à prier, à écouter ce que Dieu me veut dire, tout simplement\. »

 

__\#\#5\. Le petit doigt parle :__

Le petit doigt c’est Dieu qui parle à l’oreille de mon cœur

Dieu nous parle avec les mots de la Prière\. Porter attention aux paroles de cette prière\.

 

 

__\#2ème technique de relecture : LE TARGUI__

__\#\#Etape 1 : Regarder et décrire le paysage qui nous entoure__

5 minutes de silence pour soi afin de réfléchir sur ce qui a été du relief sur cette semaine, dans sa vie, grand ravin ou belle montagne, source ou désert aride, signe de Dieu sur son chemin, ses coups de cœur, ses coups de sang…

5’ minute ensuite d’échange en équipe, où chacun est invité à citer à haute voix une phrase\.

 

__\#\#Etape 2 : Lire et orienter nos cartes__

L’animateur présente la carte choisie pour l’occasion : citation de la Bible, phrase de la charte, passage du petit prince, …

5 minutes de silence pour soi afin de réfléchir si le paysage de sa vie ressemble ou diffère de cette carte\. Quel rapport entre ce que je viens vivre et cette carte ?

5’ minute ensuite d’échange en équipe, où chacun est invité à s’exprimer à haute voix, s’il le souhaite\.

 

 

__\#\#Etape 3 : Choisir une direction__

5 minutes de silence pour réfléchir à tout ce que nous avons entendu, et si tout cela nous donne envie de prendre une décision pour demain ou dans un avenir plus lointain\. Qu’est\-ce que je désire ?

5’ ensuite d’échange en équipe \(Peut\-être que personne ne parlera\)

 

 

__\#\#Etape 4 : Pour conclure__

Un Notre Père, une prière personnelle, un chant, un « bonne nuit »…

__ __

__ __

