# -->Titre

Merci, s’il te plait, pardon



# -->Texte



Objectif : Animer un temps de relecture  en fin de journée



Matériel : Un endroit calme, autour du feu de la veillée par exemple



Déroulement :

L’animateur introduit ce temps par un chant calme (par exemple : N’aie pas peur, laisse-toi regarder par le Christ)



Ensuite, il invite les participants à faire mémoire en silence de la journée vécue en trois étapes :



MERCI

PARDON

S’IL TE PLAÎT





L’animateur invite chacun à partager un mot ou une intention

On peut conclure par le Notre Père ou la Prière Scoute





