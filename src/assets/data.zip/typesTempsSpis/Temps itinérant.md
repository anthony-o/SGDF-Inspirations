# -->Titre

Temps itinérant



# -->Texte

Un temps spirituel itinérant est un temps associé à la thématique du chemin ou de la route. Les participants vont se déplacer durant le temps.



Par exemple l’accueil aura lieu à un endroit, puis le groupe se déplacera à un second endroit où ils rencontreront un animateur qui lira un texte, puis le groupe ira à un troisième point.



Ce type de temps spirituel est approprié pour permettre un cheminement “par étape” durant lequel chaque lieu physique correspond à une étape du cheminement

