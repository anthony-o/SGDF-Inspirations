# -->Titre

Veillee de priere



# -->Texte

L’enjeu est de proposer plusieurs lieux de prières et de permettre aux participants de circuler librement de l’un à l’autre.



Proposition de déroulé



Objectif : Animer un moment de prière

Matériel : 4 feux, 4 bibles, quelques textes, une guitare, une flûte…

Déroulement :



Quatre lieux proches du camp auront été choisis : calmes et retirés. Là, un feu, avec une provision de bois, une bible, quelques textes…



Un jeune lit un passage de l’Évangile. Silence, puis échange. Quelques accords de guitare. Silence.





Puis les  participants peuvent changer de lieu. Chaque lieu a sa spécificité. Par exemple :

                           1- Amour 2- Foi 3-Espérance 4-Action

            ou       1-Aimer  2-Écouter 3-Donner 4-Pardonner





En fin de soirée, les jeunes se  retrouvent autour d’un grand feu commun et les différentes réflexions sont rassemblées en une prière collective.



