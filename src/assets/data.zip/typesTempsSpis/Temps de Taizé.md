# -->Titre

Temps de Taizé



# -->Texte

Un temps de taizé est un temps méditatif permettant à chaque participant d’avoir une démarche d’introspection et de prière.



Durant ce temps, les participants chantent un chant de taizé en boucle. Usuellement un même chant peut durer 10mn.



Chants de taizé

https://www.youtube.com/watch?v=Yl9wSG8jFYQ&list=RDYl9wSG8jFYQ&t=2

