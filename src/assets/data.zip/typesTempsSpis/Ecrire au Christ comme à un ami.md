\# \-\->Titre

###### <a id="_3o9t84kcxr04"></a>Écrire au Christ comme à un ami

\# \-\->Texte

###### <a id="_mdm8l9ouzn69"></a>Objectif : Animer un moment de prière

###### <a id="_iv4vs2tsxbtd"></a>Matériel : une carte postale et un stylo par participant

###### <a id="_4767b8pv8b66"></a>Déroulement :

###### <a id="_gbwql25wnezw"></a>Chacun reçoit une carte postale et est invité à écrire dessus un message adressé au Christ avec des mots de tous les jours\. Insister sur la sincérité\. Si le Christ est pour nous un ami, lui écrire en ami\. Si le Christ est un inconnu, lui écrire comme tel\.

###### <a id="_gbwql25wnezw"></a>Les cartes sont mélangées et redistribuées, chacun lit la prière d’un autre \(les signatures ne sont pas révélées lors de cette lecture\.\)

###### <a id="_laabwn61k953"></a>Après la prière, pour introduire, par exemple, un partage sur Jésus\-Christ, demander de rédiger l’adresse pour faire parvenir cette carte à Jésus\. À partir de la manière dont est rédigée cette adresse, on peut facilement introduire un partage sur l’image de Jésus\-Christ, de l’Église, de Dieu__\.__

###### <a id="_gbwql25wnezw"></a>

###### <a id="_eb8hxfypi938"></a>

