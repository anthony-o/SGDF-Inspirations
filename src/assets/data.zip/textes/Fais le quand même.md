# -->Titre

Une bougie vous parle



# -->Texte

Les gens sont souvent déraisonnables, illogiques et centrés sur eux-mêmes, Pardonnes les quand même... 

Si tu es gentil, les gens peuvent t'accuser d'être égoïste et d'avoir des arrières pensées, Sois gentil quand même... Si tu réussis, tu trouveras des faux amis et des vrais ennemis, Réussis quand même... 

Si tu es honnête et franc, il se peut que les gens abusent de toi, Sois honnête et franc quand même... 

Ce que tu as mis des années à construire, quelqu'un pourrait le détruire en une nuit, Construis quand même... 

Si tu trouves la sérénité et la joie, ils pourraient être jaloux, Sois heureux quand même... Le bien que tu fais aujourd'hui, les gens l'auront souvent oublié demain, Fais le bien quand même... 

Donnes au monde le meilleur que tu as, et il se pourrait que cela ne soit jamais assez, Donnes au monde le meilleur que tu as quand même... 

Tu vois, en faisant une analyse finale, c'est une histoire entre toi et Dieu, cela n'a jamais été entre eux et toi.

Mère Térésa



