# -->Titre

Etre chef



# -->Texte

Si tu veux être chef un jour,Pense à ceux qui te seront confiés, et dis toi bien que,

Si tu ralentis, ils s’arrêtent,

Si tu faiblis, ils flanchent,

Si tu t’assieds, ils se couchent,

Si tu doutes, ils désespèrent,

Si tu critiques, ils démolissent,

Si tu marches devant, ils te dépasseront,

Si tu donnes la main, ils donneront leur peau,

Si tu pries... alors ils seront des saints.

Michel MENU



