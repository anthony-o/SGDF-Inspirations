# -->Titre

L’espérance du monde



# -->Texte

## L’espérance du monde



Aujourd’hui, dans la nuit du monde et dans l’espérance, j’affirme ma foi dans l’avenir de l’humanité. Je refuse de croire que les circonstances actuelles rendent les hommes incapables de faire une terre meilleure. Je refuse de partager l’avis de ceux qui prétendent l’homme à ce point captif de la nuit que l’aurore de la paix et de la fraternité ne pourra jamais devenir une réalité.

Je crois que la vérité et l’amour, sans conditions, auront le dernier mot effectivement. La vie, même vaincue provisoirement, demeure toujours plus forte que la mort.

Je crois fermement qu’il reste l’espoir d’un matin radieux, je crois que la bonté pacifique deviendra un jour la loi. Chaque homme pourra s’asseoir sous son figuier, dans sa vigne, et plus personne n’aura de raison d’avoir peur.

Barack Obama



