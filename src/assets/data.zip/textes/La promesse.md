# -->Titre

La promesse



# -->Texte

Devant un feu tranquille, viens faire ta Promesse.

Ce n’est pas difficile, ce n’est pas audacieux, 

ce n’est pas présomptueux de promettre 

qu’on veut faire tout son possible 

pour servir Dieu, aider son prochain, obéir à la Loi.



Ce n’est pas difficile parce que tu ne promets pas de ne jamais faillir, 

tu ne promets pas de ne jamais désobéir, de ne jamais te tromper, 

cela tu ne le pourrais pas, car tu n’es pas une sainte, 

pas plus que moi, pas plus que nous.

Tu promets seulement de faire tout ton possible… ce que tu peux, 

comme tu peux, de ton mieux.



Devant ce feu tranquille, viens faire ta Promesse.



La Promesse est une force, 

une direction que tu donnes à ton effort. 

Et l’effort te conduira d’effort en effort, à travers la vie, 

jusqu’au but que tu t’es proposé.



La Promesse est une force. 

Quand tu l’auras faite, tu ne seras pas meilleure, tu seras plus forte. 

Et s’il t’arrive un jour d’hésiter, 

de ne pas très bien savoir si telle chose est faisable 

ou si elle est de celles qui ne doivent pas se faire, 

tu te souviendras qu’un soir, devant un feu tranquille, 

à l’heure où les clartés se voilent, 

où les bruits s’apaisent, 

au milieu des camarades qui avaient le même idéal que toi, 

tu as promis de servir Dieu, et tu n’hésiteras plus. 

Tu sauras si la chose est faisable 

ou si elle est de celles qui ne doivent pas se faire.



La Promesse est une force. 

Tu ne seras pas toujours aussi bien disposée qu’aujourd’hui. 

Tu n’auras pas toujours cette joie débordante ou cette calme sérénité, 

parce qu’il y a des tourments dans la vie, 

de grandes lassitudes, 

des chagrins d’enfants et des tristesses d’adultes, 

de soudaines incertitudes.



Alors, peut-être, par un triste matin d’une triste journée, 

tu te diras : « A quoi bon tout cela ?... » 

et puis tu te souviendras qu’un soir, 

devant un feu tranquille, 

à l’heure où les clartés se voilent, 

où les bruits s’apaisent, 

au milieu des camarades qui avaient le même idéal que toi, 

tu as promis de servir Dieu. »



_Aimée Degallier-Martin (totem Lézard)_



