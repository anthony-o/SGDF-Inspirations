# -->Titre

Si tu veux construire un bateau



# -->Texte

Si tu veux construire un bateau, ne rassemble pas tes hommes et femmes pour leur donner des ordres, pour expliquer chaque détail, pour leur dire où trouver chaque chose… Si tu veux construire un bateau, fais naître dans le cœur de tes hommes et femmes le désir de la mer."

Antoine de Saint-Exupéry



