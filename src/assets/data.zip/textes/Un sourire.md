# -->Titre

Un sourire



# -->Texte

Un sourire ne coûte rien et produit beaucoup, Il enrichit ceux qui le reçoivent Sansappauvrir ceux qui le donnent. Il ne dure qu'un instant Mais son souvenir est parfoiséternel.

Personne n'est assez riche pour s'en passer, Personne n'est assez pauvre pour qu'il soitinutile, Personne n'est assez méprisable pour ne pas le mériter.

Il crée le bonheur au foyer, soutient en affaires et au travail, Il est le signe sensible del'amitié.

Un sourire donne du repos à l'être fatigué, Rend courage aux plus découragés.Il ne peut ni s'acheter, ni se prêter, ni se voler Car il n'a de valeur qu'à partir du momentoù il se donne.

Et si quelquefois vous rencontrez une personne Qui ne sait plus avoir le sourire, Soyezgénéreux, donnez-lui le vôtre, Car nul n'a autant besoin d'un sourire Que celui qui nepeut en donner aux autres..



Anonyme



