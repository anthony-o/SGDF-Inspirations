# -->Titre

Petites béatitudes



# -->Texte

## Petites béatitudes

 

Heureux ceux qui savent rire d’eux-même :

Ils n’ont pas fini de s’amuser.

 

Heureux ceux qui savent distinguer une montagne d’une taupinière :

il leur sera épargné bien des tracas.

 

Heureux ceux qui sont capables de se reposer, et de dormir sans chercher d’excuses :

Ils deviendront sages.

 

Heureux ceux qui savent se taire et écouter :

Ils en apprendront des choses nouvelles !

 

Heureux ceux qui sont assez intelligents pour ne pas se prendre au sérieux :

Ils seront appréciés de leur entourage.

 

Heureux êtes-vous si vous savez regarder sérieusement les petites choses et paisiblement les  choses sérieuses :

Vous irez loin dans la vie

 

Heureux êtes- vous si vous savez admirez un sourire et oublier une grimace :

Votre route sera ensoleillée.

 

Heureux êtes-vous si vous savez vous taire et sourire même lorsqu’on vous coupe la parole, lorsqu’on vous contredit ou qu’on vous marche sur les pieds :

L’Evangile commence à pénétrer votre cœur.

 

Heureux surtout vous qui savez reconnaitre le Seigneur, en tous ceux que vous rencontrerez :

Vous avez trouvé la vraie lumière, vous avez trouvé la véritable sagesse. 



