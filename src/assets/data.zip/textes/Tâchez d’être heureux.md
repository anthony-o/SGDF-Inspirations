# -->Titre

Tâchez d’être heureux



# -->Texte

##Tâchez d’être heureux

 

Allez tranquillement parmi le vacarme et la hâte, et souvenez-vous de la paix qui peut exister dans le silence.

Sans aliénation, vivez autant que possible en bons termes avec toutes personnes. Dites doucement  et clairement votre vérité, et écoutez les autres, même le simple d’esprit et l’ignorant ; ils ont eux aussi leur histoire. Évitez les individus bruyants et agressifs, ils sont une vexation pour l’esprit.

 

Ne vous comparez avec personne : vous risqueriez de devenir vain ou vaniteux. Il y a toujours plus grands et plus petits que vous. Jouissez de vos projets aussi bien que de vos accomplissements. Soyez toujours intéressé à votre carrière, si modeste soit-elle ; c’est une véritable possession dans les prospérités changeantes du temps. Soyez prudent dans vos affaires ; car le monde est plein de fourberies. Mais ne soyez pas aveugle en ce qui concerne la vertu qui existe ; plusieurs individus recherchent les grands idéaux ; et partout la vie est remplie d’héroïsme.

 

Soyez vous-même. Surtout n’affectez pas l’amitié. Non plus ne soyez cynique en amour, car il est en face de toute stérilité et de tout désenchantement aussi éternel que l’herbe.

 

Prenez avec bonté le conseil des années, en renonçant avec grâce à votre jeunesse. Fortifiez une puissance d’esprit pour vous protéger en cas de malheur soudain. Mais ne vous chagrinez pas avec vos chimères. De nombreuses peurs naissent de la fatigue et de la solitude.

 

Au-delà d’une discipline saine, soyez doux avec vous-même. Vous êtes un enfant de l’univers, pas moins que les arbres et les étoiles ; vous avez le droit d’être ici. Et qu’il vous soit clair ou non, l’univers se déroule sans doute comme il le devrait.

 

Soyez en paix avec Dieu, quelle que soit votre conception d’elle ou de lui, et quelles que soient vos peines et vos rêves, gardez dans le désarroi bruyant de la vie, la paix dans votre âme. Avec toutes ses perfidies, ses besognes fastidieuses et ses rêves brisés, le monde est pourtant beau. Soyez positif et attentif aux autres.

 

Tâchez d’être heureux.

 

 

 

Anonyme. Ce texte a été trouvé en 1692

dans la cathédrale de Baltimore.

