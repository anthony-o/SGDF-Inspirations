# -->Titre

Le pêcheur et l’homme d’affaires



# -->Texte





Un riche d’homme d’affaires était en vacances en Inde. Un matin, sur la grève, il aperçut la barque d’un pêcheur qui rentrait.

– Oh là ! lui cria-t-il. La pêche a été bonne ?

Le pêcheur lui sourit et lui montra quelques poissons sur le sol de sa barque :

– Oui, c’est une bonne pêche.

– Il est encore tôt. Je suppose que tu y retournes.

– Y retourner ? demanda le pêcheur. Mais pour quoi faire ?

– Mais parce qu’ainsi tu en auras plus, répondit l’homme d’affaires à qui cela semblait une évidence.

– Mais pour quoi faire ? Je n’en ai pas besoin !

– Quand tu en auras plus, tu les revendras !

– Mais pour quoi faire ?

– Tu auras plus d’argent.

– Mais pour quoi faire ?

– Tu pourras changer ta vieille barque contre un joli petit bateau.

– Mais pour quoi faire ?

– Et bien, avec ton petit bateau, tu pourras avoir plus de poissons.

– Mais pour quoi faire ?

– Et bien tu pourras prendre des ouvriers.

– Mais pour quoi faire ?

– Ils pêcheront pour toi !

– Mais pour quoi faire ?

– Tu deviendras riche.

– Mais pour quoi faire ?

– Tu pourras ainsi te reposer.

Le pêcheur le regarda alors avec un grand sourire :

– C’est justement ce que je vais faire tout de suite.

 

Abbé Pierre



