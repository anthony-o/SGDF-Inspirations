# -->Titre

Les deux joies



# -->Texte



## Les deux joies



Il y a la joie qui vient du dehors

Et il y a celle qui vient du dedans.

Je voudrais que les deux soient tiennes.

Qu’elles remplissent les heures de ton jour et les jours de ta vie.

Car lorsque les deux se rencontrent et s’unissent,

Il y a un tel chant d’allégresse que ni le chant de l’alouette

ni celui du rossignol ne peuvent s’y comparer.



Mais si une seule devait t’appartenir,

si pour toi je devais choisir,

je choisirais la joie qui vient du dedans.



Parce que la joie qui vient du dehors

est comme le soleil qui se lève le matin et qui, le soir, se couche.

Comme l’arc-en-ciel qui paraît et disparaît,

comme la chaleur de l’été qui vient et se retire.



Comme le vent qui souffle et passe.

Comme le feu qui brûle puis s’éteint…

Trop éphémère, trop fugitive…



J’aime les joies du dehors.

Je n’en renie aucune.

Toutes, elles sont venues dans ma vie quand il le fallait…

Mais j’ai besoin de quelque chose qui dure,

de quelque chose qui n’a pas de fin, qui ne peut pas finir.



Et la joie du dedans ne peut pas finir.

Elle est comme une rivière tranquille, toujours la même, toujours présente.

Elle est comme le rocher,

comme le ciel et la terre qui ne peuvent ni changer ni passer.



Je la trouve aux heures de silence, aux heures d’abandon.

Son chant m’arrive au travers de ma tristesse et de ma fatigue.

Elle ne m’a jamais quitté.



C’est Dieu – c’est le chant de Dieu en moi,

cette force tranquille qui dirige les mondes et qui conduit les hommes

et qui n’a pas de fin, qui ne peut pas finir.



Il y a la joie qui vient du dedans

Et il y a celle qui vient du dehors.

Je voudrais que les deux soient tiennes.

Qu’elles remplissent les heures de ton jour et les jours de ta vie.



Mais si une seule devait t’appartenir,

si pour toi je devais choisir,

je choisirais la joie qui vient du dedans.



Aimée Degallier-Martin (totem Lézard) 



