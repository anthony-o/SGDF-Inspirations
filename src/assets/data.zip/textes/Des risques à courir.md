# -->Titre

Des risques à courir



# -->Texte



### Des risques à courir

 

Risquer c’est oser

oser c’est choisir,

Choisir, c’est s’engager.

 

S’engager,

C’est toujours  risquer,

Mais risquer, c’est vivre,

La vie est faite de choix !

 

Dans tous les choix,

on prend des risques,

le risque de l’échec,

de l’erreur,

de passer à côté.

 

Le risque de souffrir,

de se perdre,

d’être écarté,

de ne pas être aimé.

 

Risquer, c’est donner,

Se donner, se dévoiler.

 

C’est osé de risquer :

Oser une parole,

Un engagement,  un projet,

Oser aimer,

Oser la solitude.

 

Mais Dieu est là.



