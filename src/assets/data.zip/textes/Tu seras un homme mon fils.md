# -->Titre

Tu seras un homme mon fils



# -->Texte

## Si



Si tu peux voir détruit l'ouvrage de ta vie

Et sans dire un seul mot te remettre à rebâtir,

Ou perdre d'un seul coup le gain de cent parties

Sans un geste et sans un soupir ;



Si tu peux être amant sans être fou d'amour,

Si tu peux être fort sans cesser d'être tendre

Et, te sentant haï, sans haïr à ton tour,

Pourtant lutter et te défendre ;



Si tu peux supporter d'entendre tes paroles

Travesties par des gueux pour exciter des sots,

Et d'entendre mentir sur toi leurs bouches folles

Sans mentir toi-même d'un seul mot ;



Si tu peux rester digne en étant populaire,

Si tu peux rester peuple en conseillant les rois

Et si tu peux aimer tous tes amis en frère

sans qu'aucun d'eux soit tout pour toi ;



Si tu sais méditer, observer et connaître

Sans jamais devenir sceptique ou destructeur ;

Rêver, mais sans laisser ton rêve être ton maître,

Penser sans n'être qu'un penseur;



Si tu peux être dur sans jamais être en rage,

Si tu peux être brave et jamais imprudent,

Si tu sais être bon, si tu sais être sage

Sans être moral ni pédant ;



Si tu peux rencontrer Triomphe après Défaite

Et recevoir ces deux menteurs d'un même front,

Si tu peux conserver ton courage et ta tête

Quand tous les autres les perdront,



Alors les Rois, les Dieux, la Chance et la Victoire

Seront à tout jamais tes esclaves soumis

Et, ce qui vaut mieux que les Rois et la Gloire,

Tu seras un homme, mon fils





Rudyard Kipling



