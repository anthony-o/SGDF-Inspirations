# -->Titre

Rappelle toi



# -->Texte



Que si un rien fait souffrir un rien aussi fait plaisir... 

Que tu peux être semeur d'optimisme, de courage, de confiance…

Que ta bonne humeur peut égayer la vie des autres... 

Que tu peux, en tout temps, dire un mot aimable... 

Que ton sourire non seulement t'enjolive, mais qu'il embellit l'existence de ceux qui t'approchent... 

Que tu as des mains pour donner et un coeur pour pardonner... 

Thomas MERTON



