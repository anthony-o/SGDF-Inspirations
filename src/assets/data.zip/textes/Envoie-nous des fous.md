# -->Titre

Envoie-nous des fous



# -->Texte

O Dieu, envoie-nous des fous, 

_qui s'engagent à fond,

qui oublient,

qui aiment autrement qu'en paroles,

qui se donnent pour de vrai et jusqu'au bout.



Il nous faut des fous,

des déraisonnables,

des passionnés,

capables de sauter dans l'insécurité:

l'inconnu toujours plus béant de la pauvreté.



Il nous faut des fous du présent,

épris de vie simple,

amants de la paix,

purs de compromission,

décidés à ne jamais trahir,

méprisant leur propre vie,

capable d'accepter n'importe quelle tâche,

de partir n'importe où:

à la fois obéissants,

spontanés et tenaces,

doux et forts.



O Dieu, envoie-nous des fous."



 



de Louis-Joseph Lebret

