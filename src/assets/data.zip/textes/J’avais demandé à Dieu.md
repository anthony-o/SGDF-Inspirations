# -->Titre

J’avais demandé à Dieu



# -->Texte

## J’avais demandé à Dieu



J’avais demandé à Dieu la force pour atteindre le succès ; il m’a rendu faible, afin que j’apprenne humblement à obéir.

J’avais demandé la santé, pour faire de grandes choses, il m’a donné l’infirmité pour que je fasse des choses meilleures.

J’avais demandé la richesse, pour que je puisse être heureux ; il m’a donné la pauvreté, pour que je puisse être sage.

J’avais demandé le pouvoir, pour être apprécié des hommes ; il m’a donné la faiblesse, afin que j’éprouve le besoin de Dieu.

J’avais demandé un compagnon, afin de ne pas vivre seul ; il m’a donné un coeur, afin que je puisse aimer tous mes frères.

J’avais demandé des choses qui puissent réjouir ma vie ; j’ai reçu la vie, afin que je puisse me réjouir de toutes choses.

Je n’ai rien eu de ce que j’avais demandé, mais j’ai reçu tout ce que j’avais espéré.

Presque en dépit de moi-même, mes prières informulées ont été exaucées.

Je suis, parmi les hommes, le plus richement comblé.

Texte anonyme



