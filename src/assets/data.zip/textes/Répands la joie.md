# -->Titre

Répands la joie



# -->Texte



##Répands la joie



Répands la joie... 

Répands la joie sur ton chemin, sur nos chemins. 

Dis, ne veux-tu pas répandre la joie? 

Oh ! oui, je le veux bien, mais d'où prendre la -joie ? 

Je connais un pays; il se nomme la Loi. 

Dans ce pays habitent la Vérité, la Volonté, l'Intelligence, la Beauté, la Bonté et la Joie. 

Commence par la Vérité. 

Elle vogue sur un lac bleu, et la voile blanche de sa barque se détache sur un ciel bleu. 

Attends patiemment; la Vérité ne se hâte pas toujours, mais elle vient toujours. 

Lorsqu'elle t'aura vue et reconnue, elle te dira: 



Sois vraie. 



Que jamais un mensonge n'effleure tes lèvres, ni médisance, ni flatterie, ni inexactitude aucune. 

Que ton oui, soit oui; que ton non, soit non; que ta promesse soit une promesse; ton témoignage, un témoignage; ton verdict, un verdict. 

Obéis à cet ordre, et tu auras conquis ta première gerbe de joie. 

Ensuite pars à la recherche de la Volonté. 

Elle habite la forêt de chênes. 

Elle est grande comme les chênes et forte comme les chênes. 

Autour d'elle, tu verras toutes les énergies du monde ligotées par elle; bâillonnées par elle ; dominées par elle qui s'en sert. 

A son service. 

Ne crains pas sa rude apparence; elle est bonne ; elle te dira simplement:



Domine-toi.



Quand la colère te secoue, quand un mot va s'échapper de ta bouche, et souiller de son odeur infecte le sillon d'air qu'il parcourra, domine-toi. 

Quand la colère te secoue, quand ton bras se lève pour frapper, quand ton pied tremble sur le sol, domine-toi. 

Quand la folie te grise, quand le délire te pousse de sottise en sottise, domine-toi. 

Quand la tristesse t'enveloppe de ses linges mouillés, quand tu veux pleurer, domine-toi. 

Quand tu veux crier, domine-toi. 

Obéis à cet ordre, et tu auras conquis la seconde gerbe de joie. 

Puis prend le chemin de la roche dite la «Grise». 

C'est là que rêve l'Intelligence. 

Son front est soucieux; son regard semble scruter l'Infini. 

Elle est belle; elle est bonne aussi. 

Ne crains pas de l'importuner; elle te dira doucement:



Comprends. Respecte.



C'est-à-dire regarde; 

C'est-a-dire observe; sonde et fouille; tourne et retourne l'objet trouvé. 

Médite la parole entendue. 

Cherche à saisir ce quelque chose qui te semble étrange. 

Cherche à l'assimiler, à le faire tien. 

Si tu ne peux pas, reconnais modestement ton impuissance, et respecte au moins; 

Ne condamne pas tout de suite; 

Ne rejette pas tout de suite; 

Ne te détourne pas tout de suite. 

Obéis à cet ordre et tu auras conquis la troisième gerbe de joie. 

Le chemin qui te reste à faire n'est point pénible: il conduit à la prairie verte, la radieuse, où vivent ensemble la Beauté et la Bonté. 

Dans les hautes graminées, elles cheminent et les semences de pissenlit s'envolent à leur passage; et les bardanes s'accrochent à leurs robes et les pavots s'effeuillent dans leurs cheveux flottants. 

Elles chantent; et leur voix est pleine d'éclat et de douceur. 

Assieds-toi. 

Attends qu'elles approchent. 

Elles se pencheront sur toi et tu n'entendras qu'un murmure:



Recherche le beau.



Aide sans te lasser. 

Obéis à cet ordre en apparence si simple et pourtant compliqué. 

Il faut un effort pour toute chose: c'est une vérité vieille comme le monde. 

Obéis à cet ordre, et tu auras conquis deux gerbes encore de joie. 

Et riche de cette richesse, tu t'en iras enfin trouver la Joie sur le sommet lumineux. 

Tu la verras, la rieuse gamine dansant dans un rayon de soleil. 

Elle rira en te voyant chargée comme un baudet. 

Elle te prendra par la main et te dira :

Maintenant va et répands la joie. 

Que ton regard soit un regard de joie. 

Que ton sourire soit un sourire de joie. 

Que ta parole soit une parole de joie. 

Que ton geste soit un geste de joie. 

Inonde ceux qui t'entourent de joie; on en manque tellement dans le monde... 

Ne crains pas d'en donner trop; 

Ne crains pas d'en manquer surtout. 

Obéis à cet ordre et tu auras 'conquis la Joie même, rieuse gamine qui cheminera toujours à tes côtés. 



Dis, ne veux-tu pas répandre la joie? 

Oh ! oui, je le veux bien.



Aimée Degallier-Martin (totem Lézard) 



