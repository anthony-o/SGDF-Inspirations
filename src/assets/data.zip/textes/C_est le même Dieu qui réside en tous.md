# -->Titre

C'est le même Dieu qui réside en tous



# -->Texte

Philosophie Hindouiste



L’homme est semblable à une taie d’oreiller. Une taie peut être rouge, une autre noire et ainsi de suite, mais toutes contiennent le même coton. Il en va de même pour les hommes : l’un est beau, l’autre est laid, un troisième pieux, un quatrième méchant, mais c’est le même Dieu qui réside en tous. 

Ramakrishna  



