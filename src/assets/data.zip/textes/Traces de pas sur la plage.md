# -->Titre

Traces de pas sur la plage



# -->Texte



Une nuit, j’ai eu un songe.

 

J’ai rêvé que je marchais le long d’une plage, en 

compagnie du Seigneur.

 

Dans le ciel apparaissaient, les unes après les autres, 

toutes les scènes de ma vie.

 

J’ai regardé en arrière et j’ai vu qu’à chaque 

scène de ma vie, il y avait deux paires de traces sur le sable:

L’une était la mienne, l’autre était celle du Seigneur.

 

Ainsi nous continuions à marcher, jusqu’à ce que tous

les jours de ma vie aient défilé devant moi.

 

Alors je me suis arrêté et j’ai regardé en arrière. 

J’ai remarqué qu’en certains endroits, il n’y avait 

qu’une seule paire d’empreintes, et cela correspondait

exactement avec les jours les plus difficiles de ma vie,

les jours de plus grande angoisse, de plus grande peur

et aussi de plus grande douleur.

 

Je l’ai donc interrogé : " Seigneur… tu m’as dit que tu

étais avec moi tous les jours de ma vie et j’ai accepté

de vivre avec Toi. Mais j’ai remarqué que dans les pires

moments de ma vie, il n’y avait qu’une seule trace de pas.

Je ne peux pas comprendre que tu m’aies laissé seul

aux moments où j’avais le plus besoin de Toi. "

 

Et le Seigneur répondit : " Mon fils, tu m’es tellement 

précieux ! Je t’aime ! Je ne t’aurais jamais abandonné,

pas même une seule minute !

 

Les jours où tu n’as vu qu’une seule trace de pas sur le

sable, ces jours d’épreuves et de souffrances, eh bien:

c’était moi qui te portais. "





