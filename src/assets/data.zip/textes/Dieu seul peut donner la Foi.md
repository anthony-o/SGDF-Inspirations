# -->Titre

Dieu seul peut donner la Foi



# -->Texte

Dieu seul peut donner la FOI, mais vous pouvez DONNER  votre TEMOIGNAGE.

Dieu seul peut donner l’ESPERANCE, mais vous pouvez RENDRE CONFIANCE à vos frères.

Dieu seul peut donner l’AMOUR,  mais vous pouvez apprendre à l’autre à AIMER.

Dieu seul peut donner la PAIX, mais vous pouvez semer l’UNION.

Dieu seul peut donner la FORCE, mais vous pouvez soutenir un DECOURAGE.

Dieu seul est le CHEMIN, mais vous pouvez l’indiquez aux AUTRES.

Dieu seul est la LUMIERE, mais vous pouvez la faire briller aux yeux de TOUS.

Dieu seul est la VIE, mais vous pouvez rendre aux autres le désir de VIVRE.

Dieu seul peut faire ce qui parait IMPOSSIBLE, mais vous pouvez faire le POSSIBLE.

Dieu seul se suffit à LUI MEME, mais il préfère compter sur VOUS.





