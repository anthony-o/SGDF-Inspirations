# -->Titre

Partir



# -->Texte



## Partir

 

Partir, c’est avant tout sortir de soi.

 

Prendre le monde comme centre, au lieu de son propre moi.

 Briser la croûte d’égoïsme

 qui enferme chacun comme dans une prison.

 

Partir, ce n’est pas braquer une loupe sur mon petit monde.

 

Partir, c’est arrêter de tourner autour de soi-même comme si on était le centre du monde et de la vie.

 

Partir ce n’est pas dévorer des kilomètres et atteindre des vitesses supersoniques, c’est avant tout regarder, s’ouvrir aux autres, aller à leur rencontre.

 

C’est trouver quelqu’un qui marche avec moi, sur la même route, non pas pour me suivre comme mon ombre, mais pour remarquer d’autres choses que moi et me les faire voir.

 

 

Dom Helder Câmara, évêque de Recife, Brésil



