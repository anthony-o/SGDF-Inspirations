# -->Titre

Invictus



# -->Texte

## Invictus

 

Dans les ténèbres qui m'enserrent

  Noires comme un puits où l'on se noie

Je rends grâce aux dieux, quels qu'ils soient

  Pour mon âme invincible et fière.

Dans de cruelles circonstances

  Je n'ai ni gémi ni pleuré

Meurtri par cette existence

  Je suis debout, bien que blessé.

En ce lieu de colère et de pleurs

  Se profile l'ombre de la Mort

Je ne sais ce que me réserve le sort

  Mais je suis, et je resterai sans peur.

Aussi étroit soit le chemin

  Nombreux, les châtiments infâmes

Je suis le maître de mon destin

  Je suis le capitaine de mon âme.

William Ernest Henley



