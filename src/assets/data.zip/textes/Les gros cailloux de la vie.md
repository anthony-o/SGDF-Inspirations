# -->Titre

Les gros cailloux de la vie !  



# -->Texte

Les gros cailloux de la vie !  





Un jour, un vieux professeur de l'École nationale d'administration publique (ENAP) fut engagé pour donner une formation sur la planification efficace de son temps à un groupe d'une quinzaine de dirigeants de grosses compagnies nord-américaines. Ce cours constituait l'un des cinq ateliers de leur journée de formation. Le vieux prof n'avait donc qu'une heure pour "passer sa matière ".  



Debout, devant ce groupe d'élite (qui était prêt à noter tout ce que l'expert allait enseigner), le vieux prof les regarda un par un, lentement, puis leur dit : "Nous allons réaliser une expérience". De dessous la table qui le séparait de ses élèves, le vieux prof sortit un immense pot Mason d'un gallon (pot de verre de plus de 4 litres) qu'il posa délicatement en face de lui. Ensuite, il sortit environ une douzaine de cailloux a peu près gros comme des balles de tennis et les plaça délicatement, un par un, dans le grand pot.

Lorsque le pot fut rempli jusqu'au bord et qu'il fut impossible d'y ajouter un caillou de plus, il leva lentement les yeux vers ses élèves et leur demanda :  

"Est-ce que ce pot est plein?".  

Tous répondirent : "Oui".  

Il attendit quelques secondes et ajouta : "Vraiment?".  

Alors, il se pencha de nouveau et sortit de sous la table un récipient rempli de gravier. Avec minutie, il versa ce gravier sur les gros cailloux puis brassa légèrement le pot. Les morceaux de gravier s'infiltrèrent entre les cailloux... jusqu'au fond du pot.  

Le vieux prof leva à nouveau les yeux vers son auditoire et redemanda : "Est-ce que ce pot est plein?". Cette fois, ses brillants élèves commençaient à comprendre son manège.  

L'un d'eux répondît: "Probablement pas!".  

"Bien!" répondit le vieux prof.  

Il se pencha de nouveau et cette fois, sortit de sous la table une chaudière de sable. Avec  attention, il versa le sable dans le pot. Le sable alla remplir les espaces entre les gros cailloux et le gravier. Encore une fois, il demanda : "Est-ce que ce pot est plein?".  

Cette fois, sans hésiter et en choeur, les brillants élèves répondirent : "Non!".  

"Bien!" répondît le vieux prof.  

Et comme s'y attendaient ses prestigieux élèves, il prit le pichet d'eau qui était sur la table et remplit le pot jusqu'a ras bord. Le vieux prof leva alors les yeux vers son groupe et demanda : "Quelle grande vérité nous démontre cette expérience? "  

Pas fou, le plus audacieux des élèves, songeant au sujet de ce cours, répondît : "Cela démontre que même lorsque l'on croit que notre agenda est complètement rempli, si on le veut vraiment, on peut y ajouter plus de rendez-vous, plus de choses à faire ".  

"Non" répondit le vieux prof. "Ce n'est pas cela. La grande vérité que nous démontre cette expérience est la suivante: si on ne met pas les gros cailloux en premier dans le pot, on ne pourra jamais les faire entrer tous ensuite". Il y eut un profond silence, chacun prenant

conscience de l'évidence de ces propos.  

Le vieux prof leur dit alors : "Quels sont les gros cailloux dans votre vie?" "Votre santé?" "Votre famille?" "Vos ami(e)s?" "Réaliser vos rêves?" "Faire ce que vous aimez?" "Apprendre?" "Défendre une cause?" "Relaxer?" "Prendre le temps...?" "Ou... toute autre chose?"    

"Ce qu'il faut retenir, c'est l'importance de mettre ses GROS CAILLOUX en premier dans sa vie, sinon on risque de ne pas réussir...sa vie. Si on donne priorité aux peccadilles (le gravier, le sable), on remplira sa vie de peccadilles et on n'aura plus suffisamment de temps précieux

à consacrer aux éléments importants de sa vie.  

Alors, n'oubliez pas de vous poser à vous-même la question : "Quels sont les GROS CAILLOUX dans ma vie?"  

Ensuite, mettez-les en premier dans votre pot (vie)"  

D'un geste amical de la main, le vieux professeur salua son auditoire et lentement quitta la salle.  

Auteur inconnu





