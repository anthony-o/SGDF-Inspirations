# -->Titre

Le jour où je me suis aimé



# -->Texte

Le jour où je me suis aimé pour de vrai, J’ai compris qu’en toutes circonstances, j’étais à la bonne place, au bon moment. Et, alors, j’ai pu me relaxer. Aujourd’hui je sais que ça s’appelle Estime de soi. 

Le jour où je me suis aimé pour de vrai, J’ai pu percevoir que mon anxiété et ma souffrance émotionnelle, n’étaient rien d’autre qu’un signal alors que je vais à l’encontre de mes convictions. Aujourd’hui je sais que ça s’appelle Authenticité. 

Le jour où je me suis aimé pour de vrai, J’ai cessé de vouloir une vie différente, Et j’ai commencé à voir que tout ce qui m’arrive contribue à ma croissance personnelle. Aujourd’hui je sais que ça s’appelle Maturité. 

Le jour où je me suis aimé pour de vrai, J’ai commencé à percevoir l’abus dans le fait de forcer une situation, ou une personne, dans le seul but d’obtenir ce que je veux, sachant très bien que ni la personne ni moi-même ne sommes prêts et que ce n’est pas le moment. Aujourd’hui, je sais que ça s’appelle Respect. 

Le jour où je me suis aimé pour de vrai, J’ai commencé à me libérer de tout ce qui ne m’était pas salutaire, personnes, situations, tout ce qui baissait mon énergie. Au début, ma raison appelait ça de l’égoïsme. Aujourd’hui je sais que ça s’appelle Amour Propre. 

Le jour, où je me suis aimé pour de vrai, J’ai cessé d’avoir peur du temps libre et j’ai arrêté de faire de grands plans, j’ai abandonné les mégaprojets du futur. Aujourd’hui je fais ce qui est correct, ce que j’aime, quand ça me plaît et à mon rythme. Aujourd’hui, je sais que ça s’appelle Simplicité. 

Le jour où je me suis aimé pour de vrai, J’ai cessé de chercher à toujours avoir raison et me suis rendu compte de toutes les fois où je me suis trompé. Aujourd’hui, j’ai découvert l’Humilité. Le jour où je me suis aimé pour de vrai, J’ai cessé de revivre le passé et de me préoccuper de l’avenir. Aujourd’hui, je vis au présent, là où toute la vie se passe. Aujourd’hui, je vis une seule journée à la fois, Et ça s’appelle Plénitude. 

 Le jour où je me suis aimé pour de vrai, J’ai compris que ma tête pouvait me tromper et me décevoir, Mais si je la mets au service de mon cœur, elle devient un allié très précieux. Tout ceci, c’est… le Savoir vivre. Nous ne devons pas avoir peur de nous confronter. Du chaos naissent les étoiles. 



Charlie Chaplin



