# -->Titre
Extraits du "Tao Te King" de Lao Tseu

# -->Texte
Pourquoi le ciel existe-t-il, et la terre dure-t-elle ? Parce qu'il ne vivent pas pour eux-mêmes.

_[...]_

La bonté suprême est comme l'eau qui favorise tout et ne rivalise avec rien.

_[...]_

Produire et faire croître, produire sans s'approprier, agir sans rien attendre, guider sans contraindre, c'est la vertu suprême.

_[...]_

Il y avait quelque chose d'indéterminé avant la naissance de l'univers. Ce quelque chose est muet et vide. Il est indépendant et inaltérable. Il circule partout sans se lasser jamais. Il doit être la Mère de l'univers. Ne connaissant pas son nom, je le dénomme "Tao".

_"Tao Te King" de Lao Tseu_
