# -->Titre

Heureux ceux qui...



# -->Texte

Heureux ceux qui respectent mes mains décharnées et mes pieds déformés. 

Heureux ceux qui conversent avec moi bien que j’aie désormais quelque peine à bien entendre leurs paroles. 

Heureux ceux qui comprennent que mes yeux commencent à s’embrumer et mes idées à s’embrouiller. Heureux ceux qui, en perdant du temps à bavarder avec moi, gardent le sourire. 

Heureux ceux qui jamais ne me font observer : « C’est la troisième fois que vous me racontez cette histoire ! ». 

Heureux ceux qui m’assurent qu’ils m’aiment et que je suis encore bonne ou bon à quelque chose. Heureux ceux qui m’aident à vivre l’automne de ma vie...  

St Vincent de Paul



