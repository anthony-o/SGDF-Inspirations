# -->Titre

Dernière lettre



# -->Texte

## Dernière lettre



Chers éclaireurs,

Si par hasard, vous avez assisté à la représentation de Peter Pan, vous vous souviendrez que le chef des pirates était toujours en train de préparer son dernier discours, car il craignait fort que l’heure de sa mort venue, il n’eût plus le temps de le prononcer. C’est à peu près la situation dans laquelle je me trouve, et bien que je ne sois pas sur le point de mourir, je sais que cela m’arrivera un de ces prochains jours et je désire vous envoyer un mot d’adieu.



Rappelez-vous que c’est le dernier message que vous recevrez de moi ; aussi méditez-le.

J’ai eu une vie très heureuse et je voudrais qu’on puisse en dire autant de chacun de vous.

Je crois que Dieu nous a placés dans ce monde pour y être heureux et pour y jouir de la vie. 



Ce n’est ni la richesse, ni le succès, ni la satisfaction égoïste de nos appétits qui créent le bonheur. Vous y arriverez tout d’abord en faisant de vous, dès l’enfance, des êtres sains et forts qui pourront plus tard se rendre utiles et jouir ainsi de la vie lorsqu’ils seront des hommes.



L’étude de la nature vous apprendra que Dieu a créé des choses belles et merveilleuses afin que vous en jouissiez. Contentez-vous de ce que vous avez et faites-en le meilleur usage possible. Regardez le beau côté des choses plutôt que le côté sombre.



Mais le véritable chemin du bonheur est de donner celui-ci aux autres. Essayez de quitter la terre en la laissant un peu meilleure que vous ne l’avez trouvée et quand l’heure de la mort approchera, vous pourrez mourir heureux en pensant que vous n’avez pas perdu votre temps et que vous avez fait « de votre mieux ». 



Soyez toujours prêts à vivre heureux et à mourir heureux. 



Soyez toujours fidèles à votre Promesse scoute même quand vous aurez cessé d’être un enfant - et que Dieu vous aide à y parvenir !



Votre ami,

Robert Baden-Powell



