# -->Titre
Extraits d'"Autoportrait au radiateur" de Christian Bobin

# -->Texte
Je n'aime pas ceux qui parlent de Dieu comme d'une valeur sûre. Je n'aime pas non plus veux qui en parlent comme d'une infirmité de l'intelligence. Je n'aime pas ceux qui savent, j'aime ceux qui aiment. On peut fort bien, par temps clair, entrevoir Dieu sur le visage premier venu. Voilà. C'est aussi simple que cela. Et personne ne nous a jamais dit que ce qui était simple n'était pas déchirant.

_[...]_

"Infiniment plus que tout" : c'est le nom enfantin de l'amour, son petit nom, son nom secret.

_[...]_

L'angoisse suscite la beauté - comme la question réveille sa réponse. À la source d'un grand poème, d'une belle musique ou d'une architecture sacrée, il y a une angoisse que l'on apaise en lui donnant forme, rythme, mesure.

_[...]_

Je n'aime pas le mot "religieux". Je lui préfère le mot "spirituel". Et spirituelle ce qui, en nous, ne suffit pas du monde, ne s'accommode d'aucun monde. C'est quand le spirituel s'affadi qu'il devient du "religieux".

_[...]_

C'est l'imprévu que j'espère, et lui seul. Partout, toujours. Dans les plis d'une conversation, dans le gué d'un livre, dans les subtilités d'un ciel. Je le guette autant que je l'espère. Ce à quoi je ne m'attends pas, c'est cela que j'attends.

_[...]_

Dans la haine il n'y a personne, pas même celui qui hait. Pour qu'il y ait quelqu'un, il faut qu'il y ait quelqu'un d'autre, et pour qu'il y ait l'un et l'autre, il faut qu'il y ait l'amour, ou du moins son attente, son espérance, sa nostalgie, sa promesse.

_[...]_

Impossible de parler de Dieu sans prononcer aussitôt une quantité invraisemblable de bêtises. On ne peut rien dire de Dieu, seulement parler avec lui, en lui. Si cette phrase semble folle ou prétentieuse, on l'entendra sans doute mieux en remplaçant le mot "Dieu" par le mot "amour" qui est son exact équivalent : impossible de parler de l'amour sans prononcer aussitôt une quantité invraisemblable de bêtises. On ne peut rien dire de l'amour, seulement parler avec lui, en lui.

_"Autoportrait au radiateur" de Christian Bobin_
