# -->Titre

Les treize commandements de la vie



# -->Texte



Le plus grand handicap: la peur 

Le plus beau jour: aujourd'hui 

La chose la plus facile: se tromper 

La plus grande erreur: abandonner 

Le plus grand défaut: l'égoïsme 

La plus grande distraction: le travail 

La pire banqueroute: le découragement 

Les meilleurs professeurs: les enfants 

Le plus grand besoin: le bon sens 

Le plus bas sentiment: la jalousie 

Le plus beau présent: le pardon 

La plus grande connaissance: Dieu 

La plus belle chose au monde: l'amour 



