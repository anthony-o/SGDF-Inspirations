# -->Titre

Tu seras Chef



# -->Texte

## Tu seras Chef



Tu seras Chef, veux tu ? 

Non pas aujourd'hui ni demain peut-être ; 

Mais lorsque l'heure sera venue: 

Lorsque ta vie sera droite comme une tige de roseau

et simple comme un chant d'alouette



Un chef ce n'est pas celui qui veut commande, diriger,

s'imposer, celui qui donne des ordres pour se faire obéir;

Celui qui défend ou qui permet; qui blame et qui loue;

qui récompense et qui punit.

Un chef, c'est autre chose.

C'est davantage.



Un chef, c'est celui qui , sans le vouloir et sans le savoir,

attire les autres à lui; celui auprès duquel on vient s'asseoir;

celui qu'on écoute et qu'on suit parce qu'on a découvert

qu'il y avait une force en lui que rien ne peut détruire;

que sa vie est droite, et simple son action; chaque jour la même

simple comme le regard tranquille

qui semble venir de loin et s'en aller plus loin encore

jusqu'au fond des conscience et par delà l'horizon.



Un chef...

Comme il serait bon d'avoir un chef, lorsqu'on est fatigué !

Quelqu'un qui penserait pour nous,

qui déciderait pour nous et qu'on n'aurait qu'à suivre

Mais les chefs sont rares;

Ceux là du moins en qui l'on se confie.



Tu seras Chef, veux tu ? 

Non pas aujourd'hui ni demain peut-être ; 

Mais lorsque l'heure sera venue: 

Lorsque ta vie sera droite comme une tige de roseau

et simple comme un chant d'alouette



Etre chef ce n'est pas transformer les autres

pour en faire ce qu'on est soi-même,

en leur imposant ses idées et son action;

en les poursuivant de recommandations

de défenses et de préceptes.



Etre chef c'est vivre une vie très pure

dans une maison ouverte.

Que ceux qui veulent venir viennent;

et jamais la porte ne se ferme, ni les fenêtres

car le chef vit aux yeux de tous, pour tous, avec tous.



Un chef exige beaucoup de lui-même; presque rien des autres

Il est sévère pour lui même ;

indulgent pour les autres.

Il sait bien qu'il n'est pas facile de faire les choses

et que presque tout demande un effort



Un chef, c'est un camarade que tu as reconnu meilleur que toi

et auprès duquel tu te sens devenir meilleur que toi -même.

Voilà pourquoi tu l'as choisi.

Voilà pourquoi tu lui dis : " mon Chef"



Tu seras Chef, veux tu ? 

Non pas aujourd'hui ni demain peut-être ; 

Mais lorsque l'heure sera venue: 

Lorsque ta vie sera droite comme une tige de roseau

et simple comme un chant d'alouette



Aimée Degallier-Martin (totem Lézard) 



