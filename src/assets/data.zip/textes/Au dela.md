# -->Titre

Au delà



# -->Texte

Au-delà des mots et des dires Il y a des silences complices 

Au-delà des mers démontées Il y a des terres nouvelles 

Au-delà des cris et des larmes Il y a des tendresses infinies 

Au-delà des vents contraires Il y a des brises parfumées 

Au-delà des violences du temps Il y a l’homme, toujours l’homme 

Que Dieu te donne de voir au-delà des évidences son visage en tout homme. 



Anonyme



