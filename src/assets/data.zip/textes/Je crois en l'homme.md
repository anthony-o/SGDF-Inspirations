# -->Titre

Je crois en l’Homme



# -->Texte



### Je crois en l’Homme

 

Je crois en l’homme, cette ordure,

Je crois en l’homme, ce fumier,

Ce sable mouvant, cette eau morte,

Je crois en l’homme, ce tordu,

Cette vessie de vanité.

 

Je crois en l’homme, cette pommade,

Ce grelot, cette plume au vent,

Ce boutefeu, ce fouille merde.

Je crois en l’homme, ce lèche sang.

Malgré tout ce qu’il a pu faire

De mortel et d’irréparable.

 

Je crois en lui

Pour la sûreté de sa main,

Pour son goût de la liberté,

Pour le jeu de sa fantaisie.

Pour son vertige devant l’étoile.

 

Je crois en lui

Pour le sel de son amitié

Pour l’eau de ses yeux, pour son rire,

Pour son élan et ses faiblesses.

 

Je crois à tout jamais en lui

Pour une amie qui s’est tendue,

Pour un regard qui s’est offert.

Et puis surtout et avant tout

Pour le simple accueil d’un berger.



 

Lucien Jacques

Extrait de Paroles de Fraternité

(Albin Michel)



