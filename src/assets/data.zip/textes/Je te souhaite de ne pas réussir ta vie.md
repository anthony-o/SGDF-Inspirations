# -->Titre

Je te souhaite de ne pas réussir ta vie



# -->Texte

Je te souhaite de ne pas réussir ta vie. 

Je te souhaite de vivre autrement que les gens arrivés. 

Je te souhaite de vivre la tête en bas et le cœur en l’air, les pieds dans tes rêves et les yeux pour entendre. 

Je te souhaite de vivre sans te laisser acheter par l’argent. Je te souhaite de vivre debout et habité. Je te souhaite de vivre le souffle en feu, brûlé vif de tendresse. 

Je te souhaite de vivre sans titre, sans étiquette, sans distinction, ne portant d’autre nom que l’humain. Je te souhaite de vivre sans que tu aies rendu quelqu’un victime de toi-même. 

Je te souhaite de vivre sans suspecter ni condamner même du bout des lèvres. Je te souhaite de vivre sans ironie même contre toi-même. 

Je te souhaite de vivre dans un monde sans exclu, sans rejeté, sans méprisé, sans humilié, ni montré du doigt, ni excommunié. 

Je te souhaite de vivre dans un monde où chacun aura droit de devenir ton frère et de devenir ton prochain. 

Un monde où personne ne sera rejeté du droit à la parole, du droit d’apprendre à lire et de savoir écrire. Je te souhaite de vivre dans un monde sans croisade, sans inquisition, sans saint office, ni chasse au sorcière. 

Je te souhaite de vivre libre, dans un monde libre d’aller et de venir, d’entrer et de sortir, libre de parler librement dans toutes les églises, dans tous les partis, dans tous les journaux, à toutes les radios, à toutes les télévisions, à toutes les tribunes, dans tous les congrès, à toutes les assemblées, dans toutes les usines, dans tous les bureaux, dans toutes les administrations. 

Je te souhaite de parler non pour être écouté mais pour être compris. Je te souhaite de vivre l’inespéré, c’est dire que Je te souhaite de ne pas réussir ta vie…



Jean Debruynne



