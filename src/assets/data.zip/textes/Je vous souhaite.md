# -->Titre

Je vous souhaite



# -->Texte

## Je vous souhaite



Je vous souhaite des rêves à n’en plus finir.

Et l’envie furieuse d’en réaliser quelques-uns.

Je vous souhaite d’aimer ce qu’il faut aimer,

et d’oublier ce qu’il faut oublier.

Je vous souhaite des passions.

Je vous souhaite des silences.

Je vous souhaite des chants d’oiseaux au réveil, et des rires d’enfants.

Je vous souhaite de respecter les différences des autres parce que le mérite et la valeur de chacun sont souvent à découvrir

Je vous souhaite de résister à l’enlisement, à l’indifférence et aux vertus négatives de notre époque.

Je vous souhaite enfin de ne jamais renoncer à la recherche, à l’aventure, à la vie, à l’amour, car la vie est une magnifique aventure et nul de raisonnable ne doit y renoncer sans livrer une rude bataille.

Je vous souhaite surtout d’être vous, fier de l’être et heureux, car le bonheur est notre destin véritable.



