# -->Titre

Une bougie vous parle



# -->Texte

Une bougie vous parle



Vous m’avez allumée et vous me regardez, rêveur. Vous êtes peut-être heureux de m’avoir. Moi, en tout cas, je me réjouis d’être allumée. Si je ne brûle pas, je serai comme les autres, dans une boîte, où je n’ai pas de signification. Ma raison d’être, je l’ai seulement, lorsque je suis allumée, car alors j’existe. Bien sûr, depuis que je suis allumée, j’ai rapetissé et bientôt je ne serai plus qu’une pâle lueur. Mais il en est ainsi : ou bien je reste entière, rangée dans une boîte et dans ce cas, je ne sais pas vraiment ce que je fais sur terre... ou bien je répands lumière et rêveries et alors je sais pourquoi je suis là, pourquoi j’existe. Pour cela, je dois donner quelque chose de moi, me donner moi-même. C’est mieux que d’être dans une boîte en carton.

Il en est de même pour vous. Ou bien vous vivez pour vous, vous ne perdez rien, mais aussi, vous ne savez pas au juste pourquoi... ou bien, vous donnez lumière et chaleur, alors les gens se réjouissent de votre présence. Vous n’êtes pas pour rien sur terre mais vous devez aussi donner quelque chose de vous. N’ayez pas peur si, ce faisant, vous devenez plus petit, c’est seulement de l’extérieur...

### Je suis une bougie unique.  

Lorsque je suis allumée la lumière et la chaleur qui se dégagent de moi ne sont pas fortes mais avec d’autres bougies, toutes ensemble, grande est notre clarté et forte est notre chaleur.

### Il en est de même pour vous.  

La lumière que vous donnez n’est pas grand chose, mais avec celle des autres, c’est énorme.

Il y a parfois des pannes de courant à la maison, il fait noir d’un seul coup.

Alors tout le monde pense : « Vite, une bougie ! » et l’obscurité est ainsi vaincue grâce à une seule flamme.

### Il en est de même pour vous.  

 Tout n’est pas idéal dans ce monde. Beaucoup se plaignent, certains n’arrêtent pas de se lamenter. N’oubliez pas qu’une seule flamme est encore plus que l’obscurité.

Prenez courage et n’attendez pas les autres. Soyez allumés et brûlez.

Et si vous avez des doutes, alors prenez une bougie et allumez la. Regardez cette flamme et comprenez.





